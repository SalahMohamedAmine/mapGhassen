/*import React, { useRef } from "react";
import Demo from "./Demo.js";

const App = () => {
    const innerRef = useRef();

    const getLocation = () => {
        innerRef.current && innerRef.current.getLocation();
    };

    return (
        <article style={{ textAlign: "center" }}>
            {/* eslint-disable-next-line no-console*//*}
            <Demo onError={(error) => console.log(error)} ref={innerRef} />
            <button
                className="pure-button pure-button-primary"
                onClick={getLocation}
                type="button"
            >
                Get location
            </button>
        </article>
    );
};

export default App;*/
import React from 'react';
import { Map, TileLayer, Marker, Popup } from 'react-leaflet';
import { geolocated } from 'react-geolocated';
/*var L = require('leaflet');
require('leaflet-routing-machine');*/
import L from 'leaflet';
import 'leaflet-routing-machine'

const DEFAULT_LONGITUDE = 35.7543054;
const DEFAULT_LATITUDE = 10.7928871;

class App extends React.Component {
    
    state = {
        
        zoom: 10,
        //isMapInit: false,
        map:null
    };

    lat= 35.5047495;
    lng= 10.5829492;

    saveMap = map => {
        this.setState({
            map:map
        });
    };
    handleChangePort = (map) => {
        this.setState({zoom:map.zoom});
    }



    componentDidUpdate(prevProps, prevState){
        
        const {  map } = this.state;
        const { coords } = prevProps;
        console.log("componentDidMount", map.leafletElement.getSize());
        if(coords){
            L.Routing.control({
                waypoints: [
                    L.latLng(this.lat, this.lng),
                    L.latLng(35.5047495, 11.0432808)
                ]
            }).addTo(map.leafletElement);
        }
         
    }
    render() {
        const { zoom, lat, lng } = this.state;
        this.lng = this.props.coords ? this.props.coords.longitude : this.lng;
        this.lat = this.props.coords ? this.props.coords.latitude : this.lat;
        
        console.log("lllllllllllll");
    
        return (
            <Map center={[this.lat, this.lng]} zoom={zoom} ref={this.saveMap} onViewportChange={this.handleChangePort}>
                <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                    />
                {
                    !this.props.coords ?
                        <div className="loading">Loading</div> :
                         null
                }
                {/*<Routing from={[57.74, 11.94]} to={[57.6792, 11.949]} />*/}
                {/*{this.state.isMapInit && <RoutingDemo map={this.map} />}*/}
            </Map>
        );
    }


}

 export default geolocated({
    positionOptions: {
        enableHighAccuracy: true
    },
    userDecisionTimeout: 5000,
    watchPosition: true
})(App);

// export default App;

